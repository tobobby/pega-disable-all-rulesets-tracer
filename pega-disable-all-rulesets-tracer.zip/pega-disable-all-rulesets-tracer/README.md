# pega-deselect-tracer
Chrome extension that adds button "Deselect Pega" rulesets for a Tracer Configuration

# usage
That extension is not published to Chrome Store yet. So in order for use it:

1. Download zip in the top right corner
2. Unpack the extension
3. Enable "Developer mode" in chrome://extensions/
4. Click the "Load unpacked extension..." button
5. Chose a directory with the unpacked extension

# screenshot
![screenshot](https://github.com/pegadevops/pega-deselect-tracer/raw/master/screenshot.png)
